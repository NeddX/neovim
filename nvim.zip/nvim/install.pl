#!/usr/bin/perl

require "./dsfx.pl";
use English qw' no-match-vars ';
use File::Copy::Recursive qw(dircopy);
use File::Copy;

my $platform = lc "$OSNAME";
our $appdata = "platform_specific_path";

print("Installing...\nNOTE: You must have git, node and npm (should come with node) installed for this config to work!\n");
print("Install them using your package manager.");
print("Platform: $platform\n");
if ($platform eq "mswin32") {
	$appdata = $ENV{"LOCALAPPDATA"} . "/nvim/";
	my $exit_code = system("powershell -Command \"git clone https://github.com/wbthomason/packer.nvim \"\$env:LOCALAPPDATA/nvim-data/site/pack/packer/start/packer.nvim\"\"");
	if ($exit_code != 0) {
		print("\nInstall failed! Aborting...\n");
		#exit -1;
	}
} else {
	$appdata = $ENV{"HOME"} . ".config/nvim";
	my $exit_code = system("git clone --depth 1 https://github.com/wbthomason/packer.nvim\
 ~/.local/share/nvim/site/pack/packer/start/packer.nvim");
	if ($exit_code != 0) {
		print("\nInstall failed! Aborting...\n");
		exit -1;
	}
}

if (!-e $appdata) {
	mkdir($appdata);
}

print("\nplatform_specific_path: $appdata\n");
dircopy("./after", $appdata . "/after/");
dircopy("./lua", $appdata . "/lua/");
copy("./init.lua", $appdata);

print("\nInstall complete!\n");
print("Launch neovim (ignore the errors) and type ':PackerSync'.\n");
print("After that relaunch again, wait for Mason to install the language servers and restart again.\n");
print("You should be good to go after the third restart.\n");
print("Enjoy.\n");
1;