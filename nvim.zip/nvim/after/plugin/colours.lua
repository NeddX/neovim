function initColours(colour)
	colour = colour or "onedark"
	vim.cmd.colorscheme(colour)
end

initColours();
