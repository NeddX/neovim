vim.keymap.set("n", "<Space>gs", vim.cmd.Git)
