require("dnvc.keymap")		-- Global keymap script
require("dnvc.packer")		-- Plugin manager script
require("dnvc.editor")		-- Editor settings
